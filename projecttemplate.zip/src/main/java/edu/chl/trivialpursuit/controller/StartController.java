package edu.chl.trivialpursuit.controller;

import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import java.io.IOException;

public class StartController {

    @FXML
    @SuppressFBWarnings("UPM_UNCALLED_PRIVATE_METHOD")

    private void onProjectButtonPressed(ActionEvent e) throws IOException {

        System.out.println("hej");

        e.consume();

    }

}