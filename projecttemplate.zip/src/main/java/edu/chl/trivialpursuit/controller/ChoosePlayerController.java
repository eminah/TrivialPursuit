package edu.chl.trivialpursuit.controller;

/**
 * Created by Rasti on 2015-05-05.
 */
public class ChoosePlayerController {
}
