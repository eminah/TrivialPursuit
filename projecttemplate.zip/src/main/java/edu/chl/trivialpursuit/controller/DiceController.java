package edu.chl.trivialpursuit.controller;

/**
 * Created by inatran on 15-04-28.
 */
public class DiceController {
}
