package edu.chl.trivialpursuit.model;

/**
 * Created by helenejarl on 2015-05-11.
 */

/**
 * This class is made to handle Alternatives
 */
public enum Alternative {
    ALTERNATIVE1,ALTERNATIVE2,ALTERNATIVE3,ALTERNATIVE4
}
