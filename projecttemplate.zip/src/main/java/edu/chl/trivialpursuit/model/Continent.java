package edu.chl.trivialpursuit.model;

/**
 * Created by Rasti on 2015-05-02.
 */
public enum Continent {
    ASIA,OCEANIA,AFRICA,SOUTH_AMERICA,NORTH_AMERICA,EUROPE,
}
