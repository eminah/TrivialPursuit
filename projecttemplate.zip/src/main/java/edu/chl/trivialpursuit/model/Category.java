package edu.chl.trivialpursuit.model;

/**
 * Created by Rasti on 2015-05-02.
 */
public enum Category {
    TECHNIC,GEOGRAPHY,HISTORY,SPORT,CULTURE,ENTERTAINMENT,AIRPLANE
}
