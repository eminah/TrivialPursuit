package edu.chl.trivialpursuit.model;

/**
 * Created by inatran on 15-04-28.
 */
public class Start {

}
