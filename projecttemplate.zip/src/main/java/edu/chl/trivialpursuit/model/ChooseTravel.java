package edu.chl.TrivialPursuit.model;

/**
 * Created by helenejarl on 2015-05-11.
 */
public class ChooseTravel {
}
