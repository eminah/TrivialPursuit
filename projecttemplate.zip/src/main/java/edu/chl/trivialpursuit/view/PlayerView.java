package edu.chl.TrivialPursuit.view;

/**
 * Created by helenejarl on 2015-05-11.
 */
public class PlayerView {
}
