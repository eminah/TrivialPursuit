package edu.chl.trivialpursuit.view;

import edu.chl.trivialpursuit.model.Player;

/**
 * Created by inatran on 15-04-28.
 */
public class DiceView {

}
