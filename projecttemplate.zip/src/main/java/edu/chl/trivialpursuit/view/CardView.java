package edu.chl.trivialpursuit.view;

/**
 * Created by helenejarl on 2015-05-07.
 */
public class CardView {
}
