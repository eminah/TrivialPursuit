package edu.chl.trivialpursuit.view;

        import javafx.fxml.FXMLLoader;
        import javafx.scene.Parent;
        import javafx.scene.Scene;

/**
 * Created by Rasti on 2015-05-04.
 */
public class GameBoardView{

    private Scene boardScene;

    public GameBoardView() throws Exception {

        Parent root = FXMLLoader.load(getClass().getResource("../../../../../resources/start.fxml"));
        this.boardScene = new Scene(root,200,375);
    }

    public Scene getBoardScene() {
        return boardScene;
    }
}
