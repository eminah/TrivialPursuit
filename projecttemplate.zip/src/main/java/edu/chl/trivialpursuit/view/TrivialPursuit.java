package edu.chl.trivialpursuit.view;

import com.airhacks.afterburner.injection.Injector;
import edu.chl.trivialpursuit.controller.StartController;
import edu.chl.trivialpursuit.model.Start;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;


/*
  Application entry class (if using standard java and Swing)
*/
public class TrivialPursuit extends Application {



    public static void main(String[] args) {
        launch();



    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        Injector.registerExistingAndInject(primaryStage);

        final StartView startView = StartView.create();
        startView.show();
    }



}
